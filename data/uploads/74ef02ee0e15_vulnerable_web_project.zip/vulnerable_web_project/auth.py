def verify_token(token):
    if token == "secret":
        return True
    else:
        return False
