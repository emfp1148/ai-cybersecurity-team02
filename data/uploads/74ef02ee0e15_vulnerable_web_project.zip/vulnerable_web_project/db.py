DB_PASSWORD = "password123"

def connect_db():
    # 비밀번호 하드코딩으로 보안 취약
    print(f"Connecting to DB with password: {DB_PASSWORD}")
    # 연결 코드 생략
